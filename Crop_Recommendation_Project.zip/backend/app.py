
from flask import Flask, request, jsonify
import joblib

app = Flask(__name__)

# Load the trained model
model = joblib.load('crop_recommendation_model.pkl')

@app.route('/recommend', methods=['POST'])
def recommend_crop():
    data = request.json
    features = [[data['N'], data['P'], data['K'], data['temperature'], data['humidity'], data['rainfall'], data['ph']]]
    prediction = model.predict(features)
    return jsonify({'recommended_crop': prediction[0]})

if __name__ == '__main__':
    app.run(debug=True)
